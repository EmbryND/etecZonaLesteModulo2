/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package xadrez;

/**
 *
 * @author Admin
 */
public class Cavalo extends Peca{
    public void mover(){
        System.out.println("Mover duas casas para frente e uma para o lado");
    }
}
